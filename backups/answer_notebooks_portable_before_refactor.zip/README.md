# Edit answer text in notebook code cells

To build fresh base notebooks from Word files, open **`generate_base_notebooks.ipynb`**
and Run All. It reads `redataforrag` and writes a combined notebook plus one per
Word file into `generated_answer_notebooks`. Each answer is raw text in a code
cell; running that cell generates its audio preview and Play/Save controls.
Regenerating preserves edits in previously generated notebooks by default.
The generator itself does not load a speech model or generate audio.

Open `answer_review.ipynb`, `answers_tts.ipynb`, or one of the three notebooks in
`answer_notebooks/`. Every answer has its own code cell with the actual text in
`text = """..."""`. There are no text-box widgets in these notebooks.

## Run one answer

```powershell
.\start_answer_review.ps1
```

1. Select **Answers TTS (CUDA)** and run the setup cell once.
2. Edit the answer's `text`, `voice`, and `speed` directly in its code cell.
3. Run that answer cell. It generates only that answer and shows Play and Save.
4. Click **Play preview**, then **Save and replace WAV** when happy.

Run the setup first, then only the answer cells you want to generate. Running all
answer cells generates every preview. The first preview loads the model.
Select your **Speaker** and use **Test speaker** to check the output device.

Save replaces the matching individual WAV at this relative path:

```text
audio_output_emphasized_punctuation/
  af_heart/
    speed_1p00/
      Video Vignette 1 MatsProRes Indicated_Streamline Script/
        answer_003.wav
        answer_003.txt
        answer_003.json
```

The voice and speed in the code determine their corresponding folders. The exact
destination appears under each player. Save writes the exact auditioned WAV and
replaces its text/metadata files. It does not run the model again. After changing
code, rerun the cell before saving. Running another answer cell does not change
an earlier preview's destination or audio. Combined tracks are separate batch outputs.

The model receives your text exactly as entered, including punctuation and line
breaks. No time stretching, added silence, smoothing, fades, normalization, or
filters are applied. Audio is native 24 kHz, 24-bit PCM WAV. The default female
voice is Heart (`af_heart`). The engine is local Kokoro-82M on CUDA.

## Save text and move to another PC

**Ctrl+S saves your actual text inside the notebook.** Running an answer cell also
backs up that text and its voice/speed settings in `answer_edits.json`.

Save the notebook before clicking **Export for another PC**. It creates
`answer_notebooks_portable.zip` with your saved notebooks, text backup, supporting
Python/PowerShell code, requirements, and the three Word scripts. It excludes
installed environments, model downloads, and audio outputs. Copy audio folders
separately if you also want the existing recordings.

On the other Windows PC, extract the ZIP and use Anaconda PowerShell Prompt:

```powershell
.\setup_tts.ps1
.\start_answer_review.ps1
```

For editing text without an NVIDIA GPU, use `.\setup_tts.ps1 -TextOnly`.
The code-cell text can be edited and saved without generating audio.
The notebook code cells are authoritative; copying `answer_edits.json` alone
provides the backup of executed text, while copying the notebook preserves its
latest code edits too.

## Environment

`setup_tts.ps1` creates the local `.conda-tts` Python 3.11 environment, installs
PyTorch 2.7.1 with CUDA 12.6 plus `requirements-tts.txt`, registers the Jupyter
kernel, and verifies GPU computation. No separate CUDA toolkit is needed.
Models are cached in `.cache/huggingface`. `requirements-tts-lock.txt` records the
installed package versions. `setup_tts.ps1 -TextOnly` uses CPU PyTorch and skips
GPU checks/model warmup.

The three Word files in `redataforrag` contain 109 answers (38, 28, and 43).
Questions are stored as source context and are not narrated. Numbering restarts
at 001 for each document. Your previous text edits were used to populate the
code cells; the Word scripts remain the original reference.

## Optional batch generation

```powershell
.\generate_audio.ps1
.\generate_audio.ps1 -EmphasizedPunctuation
```

Batch commands use the Word source scripts, optionally with punctuation presets.
They do not read your raw notebook code edits. These jobs log progress/status
in the corresponding output folder and can resume matching completed clips.

Model and voice information:
[Kokoro](https://github.com/hexgrad/kokoro),
[voices](https://huggingface.co/hexgrad/Kokoro-82M/blob/main/VOICES.md).
