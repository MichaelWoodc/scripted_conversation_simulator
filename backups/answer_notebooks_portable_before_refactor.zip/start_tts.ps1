param([string]$Notebook = 'answers_tts.ipynb')
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$ttsPython = Join-Path $PSScriptRoot '.conda-tts\python.exe'
if (-not (Test-Path -LiteralPath $ttsPython)) { throw 'Run .\setup_tts.ps1 first.' }
& $ttsPython -m jupyterlab (Join-Path $PSScriptRoot $Notebook)

