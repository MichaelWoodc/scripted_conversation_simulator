# Conversation Lab

Local browser practice, structured as a static site for later GitHub Pages use.
Each complete audio folder gets its own page. Edited recordings are the default;
the library also lets you choose the original recordings.

From the project folder:

```powershell
.\start_practice.ps1
```

Open **http://localhost:8765** in Chrome or Edge. Allow microphone access, choose a
conversation, and click Start. Read the question. Words turn green using interim
recognition. A relaxed word alignment allows omissions and minor wording changes.
After a short pause, the matching answer plays and the next question appears.

The default silence window is 0.8 seconds. **Debug** shows the live transcript,
match coverage, silence timing, events, and controls for tolerance/pause duration.
The match is a lightweight word alignment, not a semantic grading model. If the
browser service misses a question, **I'm finished** advances that one turn manually.

Recognition is stopped during response playback. A state machine and per-attempt
played-clip ledger prevent duplicate interim/final callbacks from replaying a
response. Progress is stored separately for each set in this browser. A new
attempt explicitly resets it. A clip already started before a page refresh is
not started again; remaining clips/questions continue on resume.

All source answer files remain in numeric order. Vignette 1 has one QUESTION
followed by two ANSWER blocks (011 and 012); these play in order under that one
prompt. Other repeated source questions remain separate script turns. Optional
examples in parentheses are shown as expandable context. Five obvious typos or
conditional instructions have readable prompts in `question_overrides.json`;
their full original text remains in the catalog. Incomplete folders are excluded.

## Audio and speech recognition

The local server streams existing WAVs directly from the project's audio folders,
so notebook Save replacements are used without copying audio. Refresh the page
after editing a recording to refresh its catalog revision.

The initial recognizer is Web Speech API with `interimResults = true`, using the
browser's recognition service. It may require an internet connection. The app
does not store microphone audio or transcripts. Recognition service behavior,
permissions, network latency, and accent affect actual latency and matching.

Whisper can run in-browser with WebGPU/Transformers.js and provide incremental
decoded text. It is not loaded in this first version, avoiding model download
and inference startup before a lesson. The speech adapter is isolated in
`src/assets/speech.js` for a later local streaming backend.

## GitHub Pages / static export

```powershell
.\.conda-tts\python.exe browser_practice\build_site.py --static
```

Publish the **contents** of `browser_practice/dist/` as the site. Static export
copies the WAVs into `dist/media/` and preserves relative URLs, including when
hosted under a GitHub repository path. Commit the exported media when publishing
that static snapshot. No API server, Node build, model, or API key is needed for
the published frontend. GitHub Pages provides HTTPS for microphone access.
Re-export after editing audio. No deployment is performed by the local launcher.

## Source structure

```text
browser_practice/
  src/index.html              # audio-set library
  src/session.html            # one page per audio folder
  src/assets/app.js           # guided conversation UI
  src/assets/engine.js        # fuzzy matching + once/in-order progress
  src/assets/speech.js        # recognition + microphone silence detection
  src/assets/styles.css
  question_overrides.json
  build_site.py               # DOCX/audio validation and static export
  server.py                   # localhost, live WAV serving
  dist/                       # generated site
  tests/
```

After changing frontend source, restart the local launcher to rebuild `dist`.
For microphone access use localhost or HTTPS, rather than opening HTML as a file.
