param([int]$Port = 8765)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$practicePython = Join-Path $PSScriptRoot '.conda-tts\python.exe'
if (-not (Test-Path -LiteralPath $practicePython)) { $practicePython = (Get-Command python).Source }
& $practicePython -u (Join-Path $PSScriptRoot 'browser_practice\server.py') --port $Port
